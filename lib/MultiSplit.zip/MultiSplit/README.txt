
This is a NetBeans project for the for the MultiSplitPane and
MultiSplitLayout classes.  You should be able to build everything
("Run/Clean and Build Main Project" - shift-F11) and then run
the four examples.  To run an example, select an example file 
like src\examples\Example4.java and then use "Run/Run File"
(that's shift-F6) to launch it.

If you'd like to tour the source code, you'll find it here:
The main classes:
  src\org\jdesktop\swingx\MultiSplitPane.java
  src\org\jdesktop\swingx\MultiSplitLayout.java
Some simple examples:
  src\examples\Example1.java
  src\examples\Example2.java
  src\examples\Example3.java
  src\examples\Example4.java

There are also a smattering of tests in test\multisplit\*.java.
You'll also find MultiSplitPane, MultiSplitLayout in the SwingLabs
project, see https://swinglabs.dev.java.net/.  



